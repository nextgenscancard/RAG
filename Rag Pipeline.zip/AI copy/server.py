"""
Task 4 - FastAPI Orchestrator Endpoint
A simple API server that ties together Task 1, 2, and 3.

Instead of running scripts from the terminal, you can now
send HTTP requests to these endpoints:

  POST /ingest       -> runs Task 1 (store transcript in ChromaDB)
  POST /query        -> runs Task 2 (ask questions, get RAG answers)
  POST /insights     -> runs Task 3 (extract action items, decisions, etc.)
  POST /orchestrate  -> runs Task 3 + optional Task 2 in one call
  GET  /status       -> check if everything is working
"""

import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
from dotenv import load_dotenv

load_dotenv()

# import our existing code from Task 1, 2, 3
from ingest import read_transcript, split_into_chunks, store_in_chroma, ingest_folder
from query import query, find_relevant_chunks, build_context, ask_llm
from insights import extract_insights, extract_from_file

app = FastAPI(
    title="Meeting Intelligence API",
    description="Ask questions about meetings and extract insights using RAG + LLM",
    version="1.0.0",
)


# ---- Request/Response models ----
# These tell FastAPI what data to expect in each request

class IngestRequest(BaseModel):
    text: Optional[str] = None       # paste transcript text directly
    file_path: Optional[str] = None  # or give a file path on disk
    title: Optional[str] = None      # optional name for the transcript

class QueryRequest(BaseModel):
    question: str                    # the question to ask
    top_k: Optional[int] = None     # how many chunks to retrieve (default 5)

class InsightRequest(BaseModel):
    text: Optional[str] = None       # paste transcript text directly
    file_path: Optional[str] = None  # or give a file path on disk

class OrchestrateRequest(BaseModel):
    text: Optional[str] = None
    file_path: Optional[str] = None
    question: Optional[str] = None   # optional follow-up question


# ---- Endpoint 1: Ingest a transcript (Task 1) ----

@app.post("/ingest")
def ingest_transcript(req: IngestRequest):
    """
    Upload a transcript to be chunked, embedded, and stored in ChromaDB.
    Send either raw text or a file path.
    """
    if req.text:
        # save text to a temp file, process it, then clean up
        temp_file = "./data/temp_upload.txt"
        os.makedirs("./data", exist_ok=True)
        with open(temp_file, "w", encoding="utf-8") as f:
            f.write(req.text)

        try:
            chunks = split_into_chunks(req.text)
            source = req.title or "uploaded_transcript"
            count = store_in_chroma(chunks, source_name=source)
        finally:
            if os.path.exists(temp_file):
                os.remove(temp_file)

        return {"message": "Transcript ingested", "chunks_created": count}

    elif req.file_path:
        if not os.path.exists(req.file_path):
            raise HTTPException(status_code=404, detail=f"File not found: {req.file_path}")

        text = read_transcript(req.file_path)
        chunks = split_into_chunks(text)
        source = req.title or os.path.basename(req.file_path)
        count = store_in_chroma(chunks, source_name=source)

        return {"message": "Transcript ingested", "chunks_created": count}

    else:
        raise HTTPException(status_code=400, detail="Send either 'text' or 'file_path'")


@app.post("/ingest/all")
def ingest_all_transcripts(folder: str = "./data/transcripts", clear: bool = False):
    """Ingest all .txt files from a folder at once."""
    if not os.path.isdir(folder):
        raise HTTPException(status_code=404, detail=f"Folder not found: {folder}")

    if clear:
        from ingest import get_embedding_fn
        from langchain_chroma import Chroma
        chroma_path = os.getenv("CHROMA_DB_PATH", "./data/chroma_db")
        db = Chroma(
            collection_name="meeting_transcripts",
            embedding_function=get_embedding_fn(),
            persist_directory=chroma_path,
        )
        db.reset_collection()

    result = ingest_folder(folder)
    return {"message": "All transcripts ingested", "total_chunks": result}


# ---- Endpoint 2: Query meetings (Task 2) ----

@app.post("/query")
def query_meetings(req: QueryRequest):
    """
    Ask a question about the ingested meeting transcripts.
    Returns an LLM-generated answer + source chunks used.
    """
    if not req.question.strip():
        raise HTTPException(status_code=400, detail="Question cannot be empty")

    try:
        result = query(req.question, top_k=req.top_k)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Query failed: {str(e)}")

    return {
        "question": req.question,
        "answer": result["answer"],
        "sources": result["sources"],
    }


# ---- Endpoint 3: Extract insights (Task 3) ----

@app.post("/insights")
def get_insights(req: InsightRequest):
    """
    Extract action items, decisions, discussion points, and
    participant contributions from a transcript.
    """
    if req.text:
        insights = extract_insights(req.text)
        return {"insights": insights}

    elif req.file_path:
        if not os.path.exists(req.file_path):
            raise HTTPException(status_code=404, detail=f"File not found: {req.file_path}")
        insights = extract_from_file(req.file_path)
        return {"insights": insights}

    else:
        raise HTTPException(status_code=400, detail="Send either 'text' or 'file_path'")


# ---- Endpoint 4: Orchestrator (Task 4 - the main one) ----

@app.post("/orchestrate")
def orchestrate(req: OrchestrateRequest):
    """
    THE ORCHESTRATOR - combines insight extraction with optional RAG query.

    This is the key endpoint for Task 4. It does two things:
    1. Always extracts structured insights from the transcript (Task 3)
    2. If a question is also provided, runs a RAG query too (Task 2)

    This way a frontend can get both the meeting summary AND
    an answer to a specific question in a single API call.
    """
    # figure out where the transcript text is coming from
    if req.text:
        transcript_text = req.text
    elif req.file_path:
        if not os.path.exists(req.file_path):
            raise HTTPException(status_code=404, detail=f"File not found: {req.file_path}")
        transcript_text = read_transcript(req.file_path)
    else:
        raise HTTPException(status_code=400, detail="Send either 'text' or 'file_path'")

    # step 1: always extract insights
    insights = extract_insights(transcript_text)

    response = {"insights": insights}

    # step 2: if a question was asked, also run RAG query
    if req.question and req.question.strip():
        try:
            query_result = query(req.question)
            response["query_answer"] = query_result["answer"]
            response["query_sources"] = query_result["sources"]
        except Exception as e:
            response["query_answer"] = f"Could not process query: {str(e)}"
            response["query_sources"] = []

    return response


# ---- Health check ----

@app.get("/status")
def health_check():
    """Check if the system is running and ChromaDB has data."""
    try:
        from langchain_chroma import Chroma
        from ingest import get_embedding_fn

        chroma_path = os.getenv("CHROMA_DB_PATH", "./data/chroma_db")
        db = Chroma(
            collection_name="meeting_transcripts",
            embedding_function=get_embedding_fn(),
            persist_directory=chroma_path,
        )
        count = db._collection.count()

        return {
            "status": "healthy",
            "chromadb_documents": count,
            "llm_model": os.getenv("OLLAMA_LLM_MODEL", "phi3"),
            "embed_model": os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text"),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Health check failed: {str(e)}")


# ---- Run the server ----

if __name__ == "__main__":
    import uvicorn
    print("Starting Meeting Intelligence API...")
    print("Open http://localhost:8000/docs for interactive API docs")
    uvicorn.run(app, host="0.0.0.0", port=8000)
