"""
Task 2 - Query System
Takes a user question, finds relevant chunks from ChromaDB,
and sends them to a local LLM (llama3 via Ollama) to get an answer.

This is the RAG (Retrieval-Augmented Generation) part:
  R - Retrieve relevant chunks from the vector database
  A - Augment the LLM prompt with those chunks as context
  G - Generate an answer using the LLM
"""

import os
from dotenv import load_dotenv
from langchain_ollama import OllamaEmbeddings, OllamaLLM
from langchain_chroma import Chroma
from langchain_core.prompts import PromptTemplate

load_dotenv()

# ---- config from .env ----
OLLAMA_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
EMBED_MODEL = os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text")
LLM_MODEL = os.getenv("OLLAMA_LLM_MODEL", "llama3")
CHROMA_PATH = os.getenv("CHROMA_DB_PATH", "./data/chroma_db")
TOP_K = int(os.getenv("TOP_K", "5"))

COLLECTION = "meeting_transcripts"


# ---- Step 1: Connect to the same ChromaDB we filled in Task 1 ----

def get_chroma_db():
    """Open the ChromaDB that was populated by ingest.py"""
    embedding_fn = OllamaEmbeddings(
        model=EMBED_MODEL,
        base_url=OLLAMA_URL
    )
    db = Chroma(
        collection_name=COLLECTION,
        embedding_function=embedding_fn,
        persist_directory=CHROMA_PATH
    )
    return db


# ---- Step 2: Search for relevant chunks ----

def find_relevant_chunks(question, top_k=None):
    """
    Search ChromaDB for chunks that are most similar to the question.

    How it works:
    1. The question gets converted to an embedding (same model as ingest)
    2. ChromaDB compares that embedding to all stored chunk embeddings
    3. Returns the top_k closest matches

    This is semantic search - it finds chunks by meaning, not keywords.
    "What was the deadline?" would match "We need it done by Friday"
    even though they share no common words.
    """
    if top_k is None:
        top_k = TOP_K

    db = get_chroma_db()
    results = db.similarity_search_with_score(question, k=top_k)

    return results


# ---- Step 3: Build context from retrieved chunks ----

def build_context(search_results):
    """
    Take the search results and format them into a single text block
    that we can paste into the LLM prompt.

    We label each chunk with its source file so the LLM can say
    things like "In the sprint planning meeting, Bob said..."
    """
    context_pieces = []

    for i, (doc, score) in enumerate(search_results, start=1):
        source = doc.metadata.get("source", "unknown")
        chunk_num = doc.metadata.get("chunk_index", "?")
        text = doc.page_content

        piece = f"[Chunk {i} | From: {source} | Part {chunk_num}]\n{text}"
        context_pieces.append(piece)

    # join all pieces with a separator between them
    full_context = "\n\n---\n\n".join(context_pieces)
    return full_context


# ---- Step 4: Ask the LLM to answer using the context ----

PROMPT_TEMPLATE = """You are a helpful meeting assistant. Answer the question
based ONLY on the meeting transcript context provided below.

If the context doesn't contain enough information to answer, say
"I don't have enough information from the transcripts to answer that."

Do not make up anything. Only use what's in the context.

Context from meeting transcripts:
{context}

Question: {question}

Answer:"""


def ask_llm(question, context):
    """
    Send the question + context to llama3 and get an answer.

    We use a low temperature (0.2) so the model sticks to facts
    from the context instead of being creative.
    """
    llm = OllamaLLM(
        model=LLM_MODEL,
        base_url=OLLAMA_URL,
        temperature=0.2
    )

    prompt = PromptTemplate(
        template=PROMPT_TEMPLATE,
        input_variables=["context", "question"]
    )

    # create a simple chain: prompt -> llm
    chain = prompt | llm

    answer = chain.invoke({
        "context": context,
        "question": question
    })

    return answer


# ---- Full query pipeline: question -> search -> context -> LLM -> answer ----

def query(question, top_k=None):
    """
    The main function. Give it a question, get back an answer.

    Returns a dict with:
    - answer: the LLM's response
    - sources: list of which chunks were used (so you can verify)
    """
    print(f"\nQuestion: {question}")
    print("-" * 50)

    # step 1: find relevant chunks
    print("Searching ChromaDB for relevant chunks...")
    search_results = find_relevant_chunks(question, top_k)
    print(f"  Found {len(search_results)} relevant chunks")

    # step 2: build context string from those chunks
    context = build_context(search_results)

    # step 3: send to LLM
    print("Asking LLM for an answer...")
    answer = ask_llm(question, context)

    # collect source info for reference
    sources = []
    for doc, score in search_results:
        sources.append({
            "source": doc.metadata.get("source", "unknown"),
            "chunk_index": doc.metadata.get("chunk_index", -1),
            "relevance_score": round(float(score), 4),
            "preview": doc.page_content[:100] + "..."
        })

    print(f"\nAnswer: {answer}")
    print(f"\nSources used: {len(sources)} chunks")
    for s in sources:
        print(f"  - {s['source']} (chunk {s['chunk_index']}, score: {s['relevance_score']})")

    return {
        "answer": answer,
        "sources": sources
    }


# ---- Run directly to test with sample questions ----

if __name__ == "__main__":
    # make sure you've run ingest.py first!
    test_questions = [
        "What was decided about rate limiting?",
        "Who is responsible for the dashboard redesign?",
        "What technology will be used for push notifications?",
    ]

    for q in test_questions:
        result = query(q)
        print("\n" + "=" * 60 + "\n")
