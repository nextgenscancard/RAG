# Task 1 — Data Pipeline Integration

## What Are We Building?

We are building a **data pipeline** that takes meeting transcript text (like the output from Whisper speech-to-text) and prepares it for intelligent searching later.

Think of it like this: you have a 20-minute meeting recording that was converted to text. Now you want to be able to ask questions like "What did Bob say about the deadline?" — but a computer can't just "read" text and understand it the way humans do. So we need to process the text in a special way.

The pipeline has **4 steps**:

```
Raw transcript (.txt file)
        |
        v
Step 1: Read the file from disk
        |
        v
Step 2: Split the text into smaller chunks (~500 characters each)
        |
        v
Step 3: Convert each chunk into numbers (embeddings) using Ollama
        |
        v
Step 4: Store those numbers in ChromaDB (a vector database)
```

After this pipeline runs, the data is ready for searching and querying (which we'll build in Task 2).

---

## Prerequisites — What You Need Installed First

### 1. Python (version 3.10 or higher)

Check if you already have it:
```bash
python3 --version
```
If not installed, download from https://www.python.org/downloads/

### 2. Ollama (runs AI models locally on your machine)

**What is Ollama?**
Ollama is a tool that lets you run AI models on your own computer instead of paying for cloud APIs like OpenAI. It's free and your data stays private.

**Install Ollama:**

On macOS:
```bash
brew install ollama
```

Or download from https://ollama.com/download

On Linux:
```bash
curl -fsSL https://ollama.ai/install.sh | sh
```

**Start Ollama (run this in a separate terminal):**
```bash
ollama serve
```

If you see `Error: listen tcp 127.0.0.1:11434: bind: address already in use` — that's fine! It means Ollama is already running.

**Pull the embedding model (one-time download, ~274MB):**
```bash
ollama pull nomic-embed-text
```

**What is nomic-embed-text?**
It's a small AI model that does one specific job: it converts text into a list of numbers (called a "vector" or "embedding"). These numbers capture the **meaning** of the text. Two sentences about similar topics will produce similar numbers, even if they use completely different words.

For example:
- "Let's schedule a follow-up meeting" → [0.23, -0.45, 0.78, ...]
- "We should have another sync next week" → [0.21, -0.43, 0.80, ...]

These two vectors are very close to each other because the sentences mean similar things. This is how we'll search by meaning later.

---

## Project Setup — Step by Step

### Step 1: Navigate to the project folder
```bash
cd /Users/ritik/Documents/Work/Mine/AI
```

### Step 2: Create a virtual environment

A virtual environment is an isolated Python setup, so the packages we install don't mess with your other Python projects.

```bash
python3 -m venv venv
```

### Step 3: Activate the virtual environment
```bash
source venv/bin/activate
```

You'll see `(venv)` appear at the start of your terminal prompt. This means you're inside the virtual environment.

### Step 4: Install the required packages
```bash
pip install -r requirements.txt
```

This installs:
- `langchain` — framework that connects AI models, databases, and text processing
- `langchain-community` — community-built integrations for LangChain
- `langchain-chroma` — LangChain's connector for ChromaDB
- `langchain-ollama` — LangChain's connector for Ollama models
- `chromadb` — the vector database where we store our embeddings
- `python-dotenv` — reads configuration from the `.env` file

---

## How the Code Works — File by File

### `.env` — Configuration File

```
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_EMBED_MODEL=nomic-embed-text
CHROMA_DB_PATH=./data/chroma_db
CHUNK_SIZE=500
CHUNK_OVERLAP=50
```

- `OLLAMA_BASE_URL` — where Ollama is running (localhost means your own machine)
- `OLLAMA_EMBED_MODEL` — which model to use for embeddings
- `CHROMA_DB_PATH` — where to save the vector database on disk
- `CHUNK_SIZE` — maximum characters per chunk (500 is a good balance)
- `CHUNK_OVERLAP` — how many characters overlap between chunks (explained below)

### `data/transcripts/sprint_planning.txt` — Sample Transcript

This is a fake meeting transcript that looks like Whisper output. It has timestamps, speaker names, and natural conversation. We use this to test our pipeline.

### `ingest.py` — The Main Pipeline Code

This is where all the logic lives. Let's go through each function:

---

#### Function 1: `read_transcript(filepath)`

```python
def read_transcript(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()
```

**What it does:** Opens a `.txt` file and returns all the text inside it.

**Why we need it:** The transcript comes as a text file on disk. We need to load it into Python memory before we can do anything with it.

**How it works:**
- `open(filepath, "r")` opens the file in read mode
- `encoding="utf-8"` makes sure special characters don't cause errors
- `f.read()` reads the entire file content as one big string

---

#### Function 2: `split_into_chunks(text)`

```python
def split_into_chunks(text):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50,
        separators=["\n\n", "\n", ". ", " ", ""]
    )
    chunks = splitter.split_text(text)
    return chunks
```

**What it does:** Takes the full transcript text and breaks it into smaller pieces.

**Why we need it:** 
- Embedding models work best with shorter text. A 5000-character transcript would produce one vague embedding that's about "everything." But 10 chunks of 500 characters each produce 10 specific embeddings, each about one part of the meeting.
- When someone asks a question, we want to find the specific part of the meeting that answers it, not the entire transcript.

**How it works:**
- `chunk_size=500` — each chunk will be roughly 500 characters max
- `chunk_overlap=50` — consecutive chunks share 50 characters at their boundaries

**Why overlap?** Imagine this text gets split:

```
Chunk 1: "...Bob said the deadline is Friday."
Chunk 2: "The deadline applies to the frontend work..."
```

Without overlap, if someone searches for "Bob's deadline for frontend", neither chunk alone has the full picture. With 50 characters of overlap:

```
Chunk 1: "...Bob said the deadline is Friday. The deadline"
Chunk 2: "The deadline applies to the frontend work..."
```

Now both chunks have the connecting context.

**Why `RecursiveCharacterTextSplitter`?**
The "recursive" part means it tries to split at the most natural boundaries first:
1. First tries to split on `\n\n` (paragraph breaks)
2. If chunks are still too big, splits on `\n` (line breaks)
3. Then on `. ` (sentence endings)
4. Then on ` ` (spaces between words)
5. Last resort: split at any character

This way, chunks land on natural text boundaries instead of cutting mid-word.

---

#### Function 3: `get_embedding_fn()`

```python
def get_embedding_fn():
    return OllamaEmbeddings(
        model="nomic-embed-text",
        base_url="http://localhost:11434"
    )
```

**What it does:** Creates a connection to the Ollama embedding model.

**Why we need it:** ChromaDB needs a function that can convert text → numbers. This function is that bridge. When we add documents to ChromaDB, it internally calls this function on each chunk's text.

---

#### Function 4: `store_in_chroma(chunks, source_name)`

```python
def store_in_chroma(chunks, source_name="unknown"):
    documents = []
    for i, chunk in enumerate(chunks):
        doc = Document(
            page_content=chunk,
            metadata={
                "source": source_name,
                "chunk_index": i,
                "total_chunks": len(chunks)
            }
        )
        documents.append(doc)

    db = Chroma(
        collection_name="meeting_transcripts",
        embedding_function=get_embedding_fn(),
        persist_directory="./data/chroma_db"
    )

    db.add_documents(documents)
    return len(documents)
```

**What it does:** Takes the text chunks, wraps them with metadata, and stores everything in ChromaDB.

**Why we need it:** ChromaDB is our vector database. It stores the text, the metadata, AND the embedding vectors. Later in Task 2, when someone asks a question, we'll search this database to find the most relevant chunks.

**How it works step by step:**

1. **Wrap chunks as Documents** — LangChain uses a `Document` class that holds:
   - `page_content`: the actual text of the chunk
   - `metadata`: extra info we attach (which file it came from, chunk position)

2. **Connect to ChromaDB** — `Chroma()` either opens an existing database or creates a new one:
   - `collection_name`: like a table name in a regular database
   - `embedding_function`: tells Chroma how to convert text → vectors
   - `persist_directory`: saves data to disk so it survives restarts

3. **Add documents** — `db.add_documents(documents)` does three things internally:
   - Calls the embedding function on each chunk's text
   - Gets back a vector (list of numbers) for each chunk
   - Stores the text + metadata + vector together in the database

**What is metadata and why do we need it?**
Metadata is extra information tagged to each chunk. When we retrieve a chunk later, we want to know:
- `source`: which meeting transcript file it came from
- `chunk_index`: which part of the meeting (beginning, middle, end)
- `total_chunks`: how many chunks the original file was split into

This helps us give better answers like "In the Sprint Planning meeting, Bob mentioned..."

---

#### Function 5: `ingest_file(filepath)` and `ingest_folder(folder_path)`

These are convenience functions that tie everything together:

- `ingest_file()` — runs the full pipeline on one file with print statements so you can see progress
- `ingest_folder()` — finds all `.txt` files in a folder and calls `ingest_file()` on each one

---

## Running Task 1

### Quick Checklist Before Running:
1. ✅ Ollama is running (`ollama serve` — or already running)
2. ✅ Embedding model is pulled (`ollama pull nomic-embed-text`)
3. ✅ Virtual environment is activated (`source venv/bin/activate`)
4. ✅ Dependencies are installed (`pip install -r requirements.txt`)

### Run the ingestion:
```bash
cd /Users/ritik/Documents/Work/Mine/AI
source venv/bin/activate
python3 ingest.py
```

### Expected Output:
```
Reading: ./data/transcripts/sprint_planning.txt
  Text length: 4523 characters
Splitting into chunks...
  Created 12 chunks
Embedding and storing in ChromaDB...
  Stored 12 chunks in ChromaDB

Done! Total chunks stored: 12
```

### Verify It Worked:
After running, you should see a new folder created at `data/chroma_db/` — this is where ChromaDB saved the embeddings.

```bash
ls data/chroma_db/
```

You can also run a quick Python check:
```python
python3 -c "
from langchain_chroma import Chroma
from langchain_ollama import OllamaEmbeddings

db = Chroma(
    collection_name='meeting_transcripts',
    embedding_function=OllamaEmbeddings(model='nomic-embed-text'),
    persist_directory='./data/chroma_db'
)
print(f'Documents in ChromaDB: {db._collection.count()}')
"
```

---

## What Happens Next?

After Task 1 is complete, the data is sitting in ChromaDB ready to be searched. In **Task 2**, we'll build a query system that:
1. Takes a user question (e.g., "What was decided about rate limiting?")
2. Converts it to an embedding using the same model
3. Finds the most similar chunks in ChromaDB
4. Passes those chunks to a language model (llama3) to generate an answer

The foundation we built here (chunking + embedding + storage) is what makes that intelligent search possible.

---

## Common Errors and Fixes

| Error | Cause | Fix |
|-------|-------|-----|
| `ModuleNotFoundError: No module named 'langchain_text_splitters'` | Virtual environment not activated | Run `source venv/bin/activate` |
| `Connection refused` on Ollama | Ollama not running | Run `ollama serve` in another terminal |
| `model not found` | Embedding model not pulled | Run `ollama pull nomic-embed-text` |
| `address already in use` when running `ollama serve` | Ollama is already running | That's fine, ignore this error |

---

## File Structure After Task 1

```
AI/
├── .env                          # Configuration values
├── requirements.txt              # Python packages needed
├── ingest.py                     # Task 1 code (this is what we built)
├── documents/
│   └── Task1_Data_Pipeline.md    # This documentation file
└── data/
    ├── transcripts/
    │   └── sprint_planning.txt   # Sample meeting transcript
    └── chroma_db/                # Created after running ingest.py
        └── (ChromaDB files)      # The stored embeddings
```
