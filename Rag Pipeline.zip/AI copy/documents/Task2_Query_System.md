# Task 2 — Query System (RAG)

## What Are We Building?

We are building a **question-answering system** that lets you ask plain English questions about your meeting transcripts and get accurate answers back.

This is called **RAG — Retrieval-Augmented Generation**:
- **Retrieval** — find the relevant parts of the transcript
- **Augmented** — attach those parts as context to the question
- **Generation** — use an LLM to write an answer based on that context

```
User asks: "What was decided about rate limiting?"
        |
        v
Step 1: Convert question to embedding (same model as Task 1)
        |
        v
Step 2: Search ChromaDB for the 5 most similar chunks
        |
        v
Step 3: Combine those chunks into a "context" block
        |
        v
Step 4: Send context + question to llama3 (local LLM)
        |
        v
Step 5: LLM reads the context and writes an answer
        |
        v
Answer: "Bob proposed using a token bucket algorithm with Redis..."
```

### Why Not Just Send the Whole Transcript to the LLM?

Two reasons:
1. **Token limits** — LLMs can only handle so much text at once. A 2-hour meeting transcript would exceed the limit.
2. **Accuracy** — when you give an LLM too much text, it gets confused and might mix up details. Giving it only the relevant chunks keeps the answer focused and accurate.

---

## Prerequisites

Everything from Task 1, plus one more model:

```bash
ollama pull llama3
```

**What is llama3?**
It's a full language model (like ChatGPT but runs locally). Unlike `nomic-embed-text` which only converts text to numbers, `llama3` can read text and write responses. It's about ~4.7GB download.

**Make sure Task 1 data is already ingested:**
```bash
cd /Users/ritik/Documents/Work/Mine/AI
source venv/bin/activate
python3 ingest.py
```

---

## How the Code Works — query.py

### Function 1: `get_chroma_db()`

```python
def get_chroma_db():
    embedding_fn = OllamaEmbeddings(model="nomic-embed-text", base_url="http://localhost:11434")
    db = Chroma(
        collection_name="meeting_transcripts",
        embedding_function=embedding_fn,
        persist_directory="./data/chroma_db"
    )
    return db
```

**What it does:** Opens the same ChromaDB database that `ingest.py` filled with data.

**Why we need the embedding function here too:** When we search ChromaDB, it needs to convert our question into an embedding first. So it uses the same `nomic-embed-text` model. This is important — the search embedding model **must** match the storage embedding model, otherwise the vectors won't be comparable.

---

### Function 2: `find_relevant_chunks(question, top_k)`

```python
def find_relevant_chunks(question, top_k=5):
    db = get_chroma_db()
    results = db.similarity_search_with_score(question, k=top_k)
    return results
```

**What it does:** Takes your question, and finds the 5 most relevant chunks from all stored transcripts.

**How similarity search works:**
1. Your question "What was decided about rate limiting?" gets turned into a vector like `[0.34, -0.12, 0.87, ...]`
2. ChromaDB compares this vector against every stored chunk's vector
3. It uses cosine similarity — basically measuring the "angle" between two vectors
4. Vectors pointing in similar directions = similar meaning
5. Returns the top 5 closest matches with their scores

**Why `similarity_search_with_score`?** The `_with_score` part gives us a number showing how close each match is. Lower score = better match. This helps us see if the results are actually relevant or just the "least bad" matches.

---

### Function 3: `build_context(search_results)`

```python
def build_context(search_results):
    context_pieces = []
    for i, (doc, score) in enumerate(search_results, start=1):
        source = doc.metadata.get("source", "unknown")
        chunk_num = doc.metadata.get("chunk_index", "?")
        text = doc.page_content
        piece = f"[Chunk {i} | From: {source} | Part {chunk_num}]\n{text}"
        context_pieces.append(piece)
    return "\n\n---\n\n".join(context_pieces)
```

**What it does:** Takes the 5 retrieved chunks and formats them into one text block that we'll paste into the LLM prompt.

**Why we label each chunk:** We add headers like `[From: sprint_planning.txt | Part 7]` so the LLM knows which meeting each piece came from. This lets it give answers like "In the sprint planning meeting, Bob mentioned..."

**Example output:**
```
[Chunk 1 | From: sprint_planning.txt | Part 7]
Bob: I'm proposing we use a token bucket algorithm implemented with Redis...

---

[Chunk 2 | From: sprint_planning.txt | Part 8]
Carol: I've worked with token bucket before. One thing to consider is burst handling...
```

---

### Function 4: `ask_llm(question, context)`

```python
def ask_llm(question, context):
    llm = OllamaLLM(model="llama3", base_url="http://localhost:11434", temperature=0.2)
    prompt = PromptTemplate(template=PROMPT_TEMPLATE, input_variables=["context", "question"])
    chain = prompt | llm
    answer = chain.invoke({"context": context, "question": question})
    return answer
```

**What it does:** Sends the context + question to llama3 and gets back a written answer.

**The prompt template:** We give the LLM strict instructions:
- Only answer from the provided context
- Don't make things up
- Say "I don't have enough information" if the context doesn't cover the question

This is important because LLMs love to be helpful and will sometimes invent plausible-sounding answers. The prompt keeps it grounded in the actual transcript data.

**What is `temperature=0.2`?**
Temperature controls randomness:
- `0.0` = always picks the most likely next word (very predictable)
- `1.0` = more random, more creative
- `0.2` = mostly predictable with slight variation (good for factual Q&A)

We use 0.2 because we want accurate, consistent answers, not creative writing.

**What is `chain = prompt | llm`?**
The `|` (pipe) operator in LangChain connects steps together. It means: "first fill in the prompt template, then send the result to the LLM." It's like a Unix pipe — output of one step becomes input of the next.

---

### Function 5: `query(question)`

This is the main function that ties all 4 steps together. It:
1. Searches ChromaDB for relevant chunks
2. Builds a context string from those chunks
3. Sends context + question to the LLM
4. Returns the answer + source references
5. Prints everything so you can see what's happening

---

## Running Task 2

### Quick Checklist:
1. ✅ Ollama is running (`ollama serve`)
2. ✅ Both models pulled (`ollama pull nomic-embed-text` and `ollama pull llama3`)
3. ✅ Task 1 data is ingested (`python3 ingest.py` was already run)
4. ✅ Virtual environment activated (`source venv/bin/activate`)

### Run the query system:
```bash
cd /Users/ritik/Documents/Work/Mine/AI
source venv/bin/activate
python3 query.py
```

### What Happens When You Run It:

The script asks 3 test questions automatically:

1. "What was decided about rate limiting?"
2. "Who is responsible for the dashboard redesign?"
3. "What technology will be used for push notifications?"

For each question, you'll see:
- Which chunks were found and from which file
- The relevance scores (lower = more relevant)
- The LLM's answer

### Expected Output (roughly):
```
Question: What was decided about rate limiting?
--------------------------------------------------
Searching ChromaDB for relevant chunks...
  Found 5 relevant chunks
Asking LLM for an answer...

Answer: Based on the sprint planning meeting, Bob proposed implementing
rate limiting using a token bucket algorithm with Redis. Each API key
would get a bucket that refills at a configurable rate. They decided to
allow bursts up to 2x the normal rate for a 10-second window. If Redis
goes down, the system would fail open (allow requests through) and fall
back to in-memory rate limiting.

Sources used: 5 chunks
  - sprint_planning.txt (chunk 7, score: 0.3421)
  - sprint_planning.txt (chunk 8, score: 0.3856)
  ...
```

### Try Your Own Questions:

Open a Python shell and ask anything:
```bash
python3 -c "
from query import query
result = query('What technical debt was mentioned?')
"
```

---

## How Task 1 and Task 2 Connect

```
Task 1 (ingest.py)                    Task 2 (query.py)
─────────────────                    ─────────────────
transcript.txt                        User question
      |                                     |
      v                                     v
split into chunks                  convert to embedding
      |                            (same model!)
      v                                     |
embed with nomic-embed-text                 v
      |                            search ChromaDB
      v                            (compare vectors)
store in ChromaDB ──────────────>        |
                                         v
                                   top 5 chunks
                                         |
                                         v
                                   send to llama3
                                         |
                                         v
                                   answer
```

The key connection: both files use the **same embedding model** (`nomic-embed-text`) and the **same ChromaDB collection** (`meeting_transcripts`). Task 1 writes to it, Task 2 reads from it.

---

## Common Errors and Fixes

| Error | Cause | Fix |
|-------|-------|-----|
| `model 'llama3' not found` | LLM model not pulled | Run `ollama pull llama3` |
| Empty or bad answers | Task 1 not run yet | Run `python3 ingest.py` first |
| Very slow response | llama3 is a big model | First run is slow (loading model), subsequent runs are faster |
| `Connection refused` | Ollama not running | Run `ollama serve` in another terminal |

---

## File Structure After Task 2

```
AI/
├── .env                          # Added OLLAMA_LLM_MODEL and TOP_K
├── requirements.txt              # Same as Task 1 (no new packages needed)
├── ingest.py                     # Task 1 - data pipeline
├── query.py                      # Task 2 - query system (NEW)
├── documents/
│   ├── Task1_Data_Pipeline.md    # Task 1 documentation
│   └── Task2_Query_System.md     # This file
└── data/
    ├── transcripts/
    │   └── sprint_planning.txt
    └── chroma_db/                # Populated by Task 1
```
