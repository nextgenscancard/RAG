# Task 3 — Structured Insight Extraction (LLM-Based)

## What Are We Building?

In Task 2, we built a system where you ask a question and get a free-form answer. That's great for exploring, but sometimes you just want a clean summary: who has action items, what was decided, what were the main topics.

Task 3 does exactly that. You give it a transcript, and it returns **structured data** — not a paragraph, but organized JSON with 4 categories:

```
Meeting Transcript
      |
      v
Send to LLM with extraction instructions
      |
      v
LLM reads and extracts:
      |
      ├── Action Items (who does what, by when)
      ├── Decisions (what was agreed on)
      ├── Key Discussion Points (main topics)
      └── Participant Contributions (who said what)
      |
      v
Clean JSON output
```

### How Is This Different From Task 2?

| | Task 2 (Query) | Task 3 (Insights) |
|---|---|---|
| **Input** | A specific question | The full transcript |
| **Output** | Free-form answer paragraph | Structured JSON with categories |
| **Uses ChromaDB?** | Yes (searches for relevant chunks) | No (sends full transcript to LLM) |
| **Use case** | "What did Bob say about X?" | "Summarize the entire meeting" |

---

## Prerequisites

Same as Task 2 — Ollama running with `tinyllama` model. No new installs needed.

```bash
# check Ollama is running
curl http://localhost:11434/api/tags
```

---

## How the Code Works — insights.py

### The Prompt (most important part)

The entire magic is in how we ask the LLM. We give it very specific instructions:

```
"Read this transcript. Extract info into JSON with these 4 sections:
 1. action_items — each with owner, task, deadline
 2. decisions — each with what was decided and who proposed it  
 3. key_discussion_points — each with topic and summary
 4. participant_contributions — each with name, role, contributions
 
 Rules: only use info from the transcript, don't make stuff up,
 return ONLY valid JSON"
```

This is called **prompt engineering** — we're not training the model or writing complex code. We're just asking it the right question in the right way.

Why this works:
- We tell it the exact JSON structure we want (with field names)
- We give it rules to prevent hallucination
- We set temperature to 0.1 so it stays factual
- We say "return ONLY JSON" so it doesn't add extra text

---

### Function 1: `extract_insights(transcript_text)`

```python
def extract_insights(transcript_text):
    llm = OllamaLLM(model="tinyllama", temperature=0.1)
    prompt = PromptTemplate(template=EXTRACTION_PROMPT, input_variables=["transcript"])
    chain = prompt | llm
    raw_response = chain.invoke({"transcript": transcript_text})
    parsed = parse_json_response(raw_response)
    return parsed
```

**What it does:** Sends the full transcript to the LLM with the extraction prompt, gets back raw text, then parses it into a Python dictionary.

**Why `temperature=0.1`?** Even lower than Task 2 (which used 0.2). For extraction, we want zero creativity — just pull facts out of the text exactly as they appear.

**Why send the full transcript?** Unlike Task 2 where we search for relevant chunks, here we want a complete summary of everything. The LLM needs to see the whole meeting to find all action items and decisions.

---

### Function 2: `parse_json_response(raw_text)`

```python
def parse_json_response(raw_text):
    # try 1: direct JSON parse
    # try 2: strip markdown code fences
    # try 3: find { ... } inside the text
    # fallback: return error with raw text
```

**What it does:** Tries multiple ways to extract valid JSON from the LLM's output.

**Why we need this:** LLMs are not perfect JSON generators. Sometimes they add text like "Here are the insights:" before the JSON. Sometimes they wrap it in markdown code fences. This function handles all those cases.

The 3 attempts:
1. **Direct parse** — maybe the LLM returned clean JSON (best case)
2. **Strip code fences** — handles when LLM wraps output in \`\`\`json ... \`\`\`
3. **Find braces** — finds the first `{` and last `}` and tries to parse everything between them

If all 3 fail, it returns the raw text in an error dict so you can see what went wrong.

---

### Function 3: `print_insights(insights)`

Just a helper that prints the JSON in a readable format with section headers. Makes the terminal output easy to scan.

---

### Function 4: `extract_from_file(filepath)`

Reads a transcript file, runs extraction, prints results, and returns the JSON. Also saves the output to `data/insights_output.json` so you can inspect it later.

---

## Running Task 3

```bash
cd /Users/ritik/Documents/Work/Mine/AI
source venv/bin/activate
python3 insights.py
```

### Expected Output (roughly):

```
Reading: ./data/transcripts/sprint_planning.txt
  Transcript length: 4523 characters
Sending transcript to LLM for extraction...

==================================================
ACTION ITEMS
==================================================
  [Carol] Fix database migration edge cases for pre-2024 users (by: Start of sprint)
  [Dave] Build dashboard frontend with activity feed and charts (by: 5 days)
  [Carol] Build activity feed API endpoint (by: Wednesday)
  [Bob] Implement rate limiting with Redis token bucket (by: Not specified)
  [Carol] Build push notification backend with RabbitMQ (by: Not specified)
  [Dave] Frontend Firebase integration for push notifications (by: 3 days)
  [Eve] Write load tests for rate limiting (by: Not specified)

==================================================
DECISIONS
==================================================
  - Prioritize database migration cleanup at start of sprint (proposed by: Alice)
  - Use token bucket algorithm with Redis for rate limiting (proposed by: Bob)
  - Allow burst traffic up to 2x normal rate for 10 seconds (proposed by: Bob)
  - Fail open if Redis goes down (proposed by: Bob)
  - Use Firebase Cloud Messaging for push notifications (proposed by: Dave)
  - Use RabbitMQ for notification message queue (proposed by: Carol)

==================================================
KEY DISCUSSION POINTS
==================================================
  [Technical Debt]
    Database migration scripts need cleanup, 15 failing integration tests
  [Dashboard Redesign]
    New activity feed, D3 charts, collapsible sidebar, needs 2 new API endpoints
  [API Rate Limiting]
    Token bucket with Redis, configurable per API key, burst handling
  [Push Notifications]
    Firebase for mobile, RabbitMQ for backend queuing, user preferences

==================================================
PARTICIPANT CONTRIBUTIONS
==================================================
  Alice (Product Manager)
    Led the meeting, set agenda, summarized decisions, assigned priorities
  Bob (Tech Lead)
    Proposed rate limiting approach, flagged technical debt
  Carol (Backend Dev)
    Took on API endpoints, migration fixes, notification backend
  Dave (Frontend Dev)
    Presented dashboard wireframes, recommended Firebase
  Eve (QA Lead)
    Planned testing strategy for rate limiting and notifications

JSON saved to ./data/insights_output.json
```

Note: Since we're using `tinyllama` (a smaller model), the output quality might vary. The structure will be correct but some details might be less precise compared to a larger model.

---

## Common Errors and Fixes

| Error | Cause | Fix |
|-------|-------|-----|
| `"error": "Could not parse LLM response as JSON"` | tinyllama sometimes outputs bad JSON | Run again — LLM output varies between runs |
| Very slow (>2 minutes) | Long transcript + small model | Normal for tinyllama, just wait |
| Missing action items or decisions | Model missed some details | Expected with small models, larger models do better |

---

## File Structure After Task 3

```
AI/
├── .env
├── requirements.txt
├── ingest.py                     # Task 1
├── query.py                      # Task 2
├── insights.py                   # Task 3 (NEW)
├── documents/
│   ├── Task1_Data_Pipeline.md
│   ├── Task2_Query_System.md
│   └── Task3_Insight_Extraction.md   # This file
└── data/
    ├── transcripts/
    │   └── sprint_planning.txt
    ├── chroma_db/
    └── insights_output.json      # Created after running insights.py
```
