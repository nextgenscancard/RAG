# Task 4 — FastAPI Orchestrator Endpoint

## What Are We Building?

In Tasks 1–3, we built standalone Python scripts that you run from the terminal. That works for testing, but in a real project you need an **API** — a web server that other programs (frontends, mobile apps, other services) can talk to over HTTP.

Task 4 wraps everything into a **FastAPI server** with clean endpoints:

```
Client (browser, Postman, frontend app)
      |
      | HTTP request
      v
FastAPI Server (server.py)
      |
      |--- POST /ingest      --> calls ingest.py (Task 1)
      |--- POST /query       --> calls query.py  (Task 2)
      |--- POST /insights    --> calls insights.py (Task 3)
      |--- POST /orchestrate --> calls Task 3 + Task 2 together
      |--- GET  /status      --> health check
```

### What is an Orchestrator?

An orchestrator is a component that **coordinates** other components. It doesn't do the heavy lifting itself — it decides what to call and in what order.

The `/orchestrate` endpoint is the orchestrator: give it a transcript and optionally a question, and it:
1. Runs insight extraction (Task 3) to get action items, decisions, etc.
2. If you also asked a question, runs the RAG query (Task 2) to answer it
3. Returns everything combined in one response

---

## Prerequisites

Everything from Tasks 1–3, plus:
- `fastapi` and `uvicorn` (already in requirements.txt)
- Tasks 1 data should be ingested (run `python3 ingest.py` first)

---

## How to Run the Server

```bash
cd /Users/ritik/Documents/Work/Mine/AI
source venv/bin/activate
python3 server.py
```

You'll see:
```
Starting Meeting Intelligence API...
Open http://localhost:8000/docs for interactive API docs
INFO:     Started server process
INFO:     Uvicorn running on http://0.0.0.0:8000
```

Now open **http://localhost:8000/docs** in your browser — you'll get an interactive Swagger UI where you can test every endpoint directly.

---

## How the Code Works — server.py

### The Request Models (Pydantic)

```python
class QueryRequest(BaseModel):
    question: str
    top_k: Optional[int] = None
```

FastAPI uses Pydantic models to define what data each endpoint expects. If someone sends a request missing the `question` field, FastAPI automatically returns a helpful error — we don't write any validation code ourselves.

---

### Endpoint 1: POST /ingest (Task 1)

**What it does:** Accepts a transcript (text or file path) and runs the Task 1 pipeline — chunk it, embed it, store in ChromaDB.

**Test with curl:**
```bash
curl -X POST http://localhost:8000/ingest \
  -H "Content-Type: application/json" \
  -d '{"file_path": "./data/transcripts/sprint_planning.txt"}'
```

**Or send raw text:**
```bash
curl -X POST http://localhost:8000/ingest \
  -H "Content-Type: application/json" \
  -d '{"text": "Alice: We need to finish the report by Friday. Bob: I will handle it.", "title": "quick_sync"}'
```

**Response:**
```json
{"message": "Transcript ingested", "chunks_created": 12}
```

---

### Endpoint 2: POST /query (Task 2)

**What it does:** Takes a question, searches ChromaDB for relevant chunks, sends them to the LLM, returns the answer.

**Test:**
```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"question": "What was decided about rate limiting?"}'
```

**Response:**
```json
{
  "question": "What was decided about rate limiting?",
  "answer": "Bob proposed using a token bucket algorithm with Redis...",
  "sources": [
    {"source": "sprint_planning.txt", "chunk_index": 7, "relevance_score": 0.34, "preview": "..."}
  ]
}
```

---

### Endpoint 3: POST /insights (Task 3)

**What it does:** Extracts structured insights (action items, decisions, etc.) from a transcript.

**Test:**
```bash
curl -X POST http://localhost:8000/insights \
  -H "Content-Type: application/json" \
  -d '{"file_path": "./data/transcripts/sprint_planning.txt"}'
```

**Response:**
```json
{
  "insights": {
    "action_items": [...],
    "decisions": [...],
    "key_discussion_points": [...],
    "participant_contributions": [...]
  }
}
```

---

### Endpoint 4: POST /orchestrate (THE MAIN ONE)

**What it does:** This is the Task 4 orchestrator. It combines Task 3 (insights) with an optional Task 2 (query) in a single call.

**Test — insights only:**
```bash
curl -X POST http://localhost:8000/orchestrate \
  -H "Content-Type: application/json" \
  -d '{"file_path": "./data/transcripts/sprint_planning.txt"}'
```

**Test — insights + question:**
```bash
curl -X POST http://localhost:8000/orchestrate \
  -H "Content-Type: application/json" \
  -d '{"file_path": "./data/transcripts/sprint_planning.txt", "question": "Who is handling the notifications?"}'
```

**Response (combined):**
```json
{
  "insights": {
    "action_items": [...],
    "decisions": [...]
  },
  "query_answer": "Carol will build the notification backend using RabbitMQ...",
  "query_sources": [...]
}
```

---

### Endpoint 5: GET /status

**What it does:** Quick health check — tells you if the server, ChromaDB, and models are working.

**Test:**
```bash
curl http://localhost:8000/status
```

**Response:**
```json
{
  "status": "healthy",
  "chromadb_documents": 12,
  "llm_model": "phi3",
  "embed_model": "nomic-embed-text"
}
```

---

## How the Orchestrator Works (Step by Step)

When you call `/orchestrate` with a transcript and a question:

```
1. Client sends POST /orchestrate
   Body: {"file_path": "...", "question": "Who has action items?"}
            |
            v
2. server.py reads the transcript file
            |
            v
3. Calls extract_insights() from insights.py (Task 3)
   --> LLM extracts action items, decisions, etc.
            |
            v
4. Sees that a question was provided
            |
            v
5. Calls query() from query.py (Task 2)
   --> Searches ChromaDB → builds context → asks LLM
            |
            v
6. Combines both results into one response
            |
            v
7. Returns JSON to the client
```

---

## Testing with the Swagger UI

The easiest way to test is the built-in docs page:

1. Start the server: `python3 server.py`
2. Open http://localhost:8000/docs in your browser
3. Click on any endpoint
4. Click "Try it out"
5. Fill in the request body
6. Click "Execute"
7. See the response below

---

## Common Errors and Fixes

| Error | Cause | Fix |
|-------|-------|-----|
| `Connection refused` on port 8000 | Server not running | Run `python3 server.py` |
| `ModuleNotFoundError: fastapi` | Package not installed | Run `pip install fastapi uvicorn` |
| Empty answers from /query | Data not ingested | Run `python3 ingest.py` first |
| Port 8000 already in use | Another server on that port | Kill it or change port: `uvicorn server:app --port 8001` |

---

## File Structure After Task 4

```
AI/
├── .env                          # Config (models, paths)
├── requirements.txt              # Added fastapi, uvicorn
├── ingest.py                     # Task 1 - data pipeline
├── query.py                      # Task 2 - RAG query
├── insights.py                   # Task 3 - insight extraction
├── server.py                     # Task 4 - FastAPI orchestrator (NEW)
├── documents/
│   ├── Task1_Data_Pipeline.md
│   ├── Task2_Query_System.md
│   ├── Task3_Insight_Extraction.md
│   └── Task4_FastAPI_Orchestrator.md   # This file
└── data/
    ├── transcripts/
    │   └── sprint_planning.txt
    ├── chroma_db/
    └── insights_output.json
```
