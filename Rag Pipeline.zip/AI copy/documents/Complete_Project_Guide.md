# Meeting Intelligence Platform — Complete Project Guide

## Table of Contents

1. [What Is This Project?](#1-what-is-this-project)
2. [How RAG Works (The Big Picture)](#2-how-rag-works-the-big-picture)
3. [Tools & Technologies Used](#3-tools--technologies-used)
4. [Full Setup From Scratch](#4-full-setup-from-scratch)
5. [Task 1 — Data Pipeline](#5-task-1--data-pipeline)
6. [Task 2 — Query System](#6-task-2--query-system)
7. [Task 3 — Structured Insight Extraction](#7-task-3--structured-insight-extraction)
8. [Task 4 — FastAPI Orchestrator](#8-task-4--fastapi-orchestrator)
9. [Testing the Complete System](#9-testing-the-complete-system)
10. [Project File Structure](#10-project-file-structure)
11. [Troubleshooting](#11-troubleshooting)

---

## 1. What Is This Project?

Imagine your team has meetings every day. Someone records them, and a tool like Whisper converts the audio into text. Now you have a pile of transcript files — but nobody wants to read 20 pages of text to find out "who was assigned to fix the login bug?"

This project solves that problem. It builds a system where you can:

- **Ask questions** about your meetings in plain English and get accurate answers
- **Automatically extract** action items, decisions, discussion points, and who contributed what
- **Access everything via an API** so a frontend or any other tool can use it

The technical term for this approach is **RAG — Retrieval-Augmented Generation**. We'll explain what that means below.

---

## 2. How RAG Works (The Big Picture)

RAG has three steps. Here's the simplest way to think about it:

### Step 1: Prepare the data (Task 1)

You can't just throw a giant transcript at an AI model. It would be too long and the answers would be vague. Instead, we:

1. **Split** the transcript into small chunks (~500 characters each)
2. **Convert** each chunk into numbers (called embeddings) that capture its meaning
3. **Store** those numbers in a special database (ChromaDB) designed for fast similarity search

Think of it like highlighting important paragraphs in a textbook and putting sticky notes on them — except a computer does it mathematically.

### Step 2: Find relevant context (Task 2, part 1)

When someone asks "What did Bob say about the deadline?", we:

1. Convert the question into numbers using the same method
2. Compare those numbers against all stored chunks
3. Find the 5 chunks that are most similar in meaning

This is called **semantic search**. It's better than keyword search because:
- Keyword search for "deadline" would miss a chunk saying "we need it done by Friday"
- Semantic search catches it because the meaning is similar

### Step 3: Generate an answer (Task 2, part 2)

We take those 5 relevant chunks and paste them into a prompt along with the question:

```
"Here is context from the meeting: [chunk 1] [chunk 2] [chunk 3]...
Question: What did Bob say about the deadline?
Please answer based only on this context."
```

The LLM reads the context and writes a focused, accurate answer. Without RAG, the LLM would have to guess or make things up. With RAG, it has the actual meeting data right in front of it.

---

## 3. Tools & Technologies Used

### Python Packages

| Package | What It Does | Why We Need It |
|---------|-------------|----------------|
| `langchain` | Framework that connects LLMs, databases, and text processing | Provides the "glue" between all the pieces — text splitters, prompt templates, chains |
| `langchain-ollama` | LangChain's connector for Ollama | Lets LangChain talk to our local LLM and embedding model |
| `langchain-chroma` | LangChain's connector for ChromaDB | Lets LangChain store/retrieve vectors from ChromaDB |
| `chromadb` | Vector database | Stores our text embeddings and does fast similarity search |
| `python-dotenv` | Reads `.env` files | Keeps config values (model names, paths) separate from code |
| `fastapi` | Web framework for building APIs | Creates the HTTP endpoints in Task 4 |
| `uvicorn` | ASGI server | Actually runs the FastAPI application |

### External Tools

| Tool | What It Does | Why We Need It |
|------|-------------|----------------|
| Ollama | Runs AI models locally on your machine | Provides both the embedding model and the language model without cloud APIs |
| nomic-embed-text | Embedding model (~274MB) | Converts text into numerical vectors for semantic search |
| phi3 | Language model (~2.3GB) | Reads context and generates answers / extracts insights |

### Why Local LLMs Instead of OpenAI?

- **Privacy**: Meeting transcripts contain sensitive business info. Nothing leaves your machine.
- **Cost**: No per-token charges. Run as many queries as you want for free.
- **No internet needed**: Works offline once models are downloaded.

---

## 4. Full Setup From Scratch

### Step 1: Install Python (3.10+)

Check if you have it:
```bash
python3 --version
```

If not, download from https://www.python.org/downloads/

### Step 2: Install Ollama

macOS:
```bash
brew install ollama
```

Linux:
```bash
curl -fsSL https://ollama.ai/install.sh | sh
```

Or download from https://ollama.com/download

### Step 3: Start Ollama

Open a **separate terminal** and run:
```bash
ollama serve
```

If you see "address already in use" — Ollama is already running, that's fine.

### Step 4: Pull the AI models

```bash
ollama pull nomic-embed-text    # embedding model (~274MB)
ollama pull phi3                # language model (~2.3GB)
```

### Step 5: Set up the Python project

```bash
cd /Users/ritik/Documents/Work/Mine/AI

# create isolated Python environment
python3 -m venv venv

# activate it (you'll see (venv) in your prompt)
source venv/bin/activate

# install all packages
pip install -r requirements.txt
```

### Step 6: Run each task in order

```bash
# Task 1: Ingest the sample transcript
python3 ingest.py

# Task 2: Test asking questions
python3 query.py

# Task 3: Extract structured insights
python3 insights.py

# Task 4: Start the API server
python3 server.py
# Then open http://localhost:8000/docs in your browser
```

---

## 5. Task 1 — Data Pipeline

**File:** `ingest.py`

**Goal:** Take a meeting transcript text file, break it into chunks, convert chunks to embeddings, and store everything in ChromaDB.

### What Each Function Does

| Function | Input | Output | Purpose |
|----------|-------|--------|---------|
| `read_transcript(filepath)` | Path to .txt file | String of text | Loads the transcript from disk into Python memory |
| `split_into_chunks(text)` | Long text string | List of ~500-char strings | Breaks text at natural boundaries (paragraphs, sentences) with 50-char overlap |
| `get_embedding_fn()` | Nothing | Ollama embedding object | Creates the bridge between text and numbers using nomic-embed-text |
| `store_in_chroma(chunks)` | List of text chunks | Number of stored docs | Wraps chunks as Documents with metadata, embeds them, saves to ChromaDB |
| `ingest_file(filepath)` | Path to .txt file | Chunk count | Runs the full pipeline on one file |
| `ingest_folder(folder)` | Path to folder | Total chunk count | Runs `ingest_file` on every .txt file in the folder |

### The Pipeline Flow

```
sprint_planning.txt (5581 characters)
        |
        v
read_transcript() reads the file
        |
        v
split_into_chunks() produces ~12 chunks of ~500 chars each
        |
        v
store_in_chroma() does two things per chunk:
   1. Calls nomic-embed-text to convert text -> vector [0.23, -0.45, 0.78, ...]
   2. Saves text + vector + metadata into ChromaDB on disk
        |
        v
Data is now searchable!
```

### Key Concepts

**Why chunk at 500 characters?**
Embedding models work best with focused text. One big embedding of the entire meeting would be a vague average. 12 smaller embeddings each capture one specific discussion topic.

**Why overlap of 50 characters?**
Without overlap, a sentence split across two chunks would lose context in both. The 50-char overlap ensures the boundary sentences appear in both neighboring chunks.

**What is metadata?**
Extra info attached to each chunk: which file it came from (`source`), its position (`chunk_index`), total chunks (`total_chunks`). This travels with the chunk everywhere and helps give better answers later.

### Run and Verify

```bash
python3 ingest.py
```

Expected output:
```
Reading: ./data/transcripts/sprint_planning.txt
  Text length: 5581 characters
Splitting into chunks...
  Created 12 chunks
Embedding and storing in ChromaDB...
  Stored 12 chunks in ChromaDB

Done! Total chunks stored: 12
```

---

## 6. Task 2 — Query System

**File:** `query.py`

**Goal:** Accept a natural-language question, find relevant chunks from ChromaDB, and use an LLM to generate an answer grounded in the actual meeting content.

### What Each Function Does

| Function | Input | Output | Purpose |
|----------|-------|--------|---------|
| `get_chroma_db()` | Nothing | ChromaDB connection | Opens the same database that Task 1 filled |
| `find_relevant_chunks(question)` | Question string | List of (document, score) pairs | Embeds the question and finds the 5 most similar chunks |
| `build_context(results)` | Search results | Formatted text block | Combines chunks into labeled context for the LLM |
| `ask_llm(question, context)` | Question + context | Answer string | Sends everything to phi3 and gets a written answer |
| `query(question)` | Question string | Dict with answer + sources | Runs the full RAG pipeline |

### The Pipeline Flow

```
"What was decided about rate limiting?"
        |
        v
find_relevant_chunks():
   1. Converts question to vector using nomic-embed-text
   2. ChromaDB compares this vector to all stored vectors
   3. Returns top 5 most similar chunks with scores
        |
        v
build_context():
   Formats the 5 chunks into a text block with headers:
   "[Chunk 1 | From: sprint_planning.txt | Part 7]
    Bob: I'm proposing we use a token bucket algorithm..."
        |
        v
ask_llm():
   Sends this prompt to phi3:
   "Here is meeting context: [context]
    Question: What was decided about rate limiting?
    Answer based only on the context."
        |
        v
phi3 reads the context and writes:
   "Bob proposed using a token bucket algorithm with Redis.
    The team decided to allow bursts up to 2x the normal rate
    for a 10-second window..."
```

### Key Concepts

**Why the same embedding model for search?**
The question must be embedded with `nomic-embed-text` (the same model used in Task 1). If you used a different model, the vectors would live in different "spaces" and similarity comparison wouldn't work.

**What does the similarity score mean?**
Lower score = better match. A score of 0.3 means the chunk is very relevant. A score of 1.5 means it's barely related. ChromaDB uses distance (not similarity), so lower is better.

**Why temperature = 0.2?**
Temperature controls randomness. 0.0 = always the same answer. 1.0 = very creative/random. For factual Q&A, we want low temperature so the model sticks to what's in the context.

**What is `chain = prompt | llm`?**
LangChain's pipe operator connects processing steps. `prompt | llm` means: fill in the prompt template first, then send the result to the LLM. Like piping commands in a terminal: `cat file | grep error`.

### Run and Verify

```bash
python3 query.py
```

It asks 3 test questions and prints answers with sources for each.

---

## 7. Task 3 — Structured Insight Extraction

**File:** `insights.py`

**Goal:** Feed the full transcript to the LLM and get back a structured JSON with action items, decisions, key discussion points, and participant contributions.

### How It Differs From Task 2

| | Task 2 (Query) | Task 3 (Insights) |
|---|---|---|
| Input | A specific question | The full transcript |
| Method | Semantic search → relevant chunks → LLM | Full transcript → LLM directly |
| Output | Free-form answer paragraph | Structured JSON |
| Uses ChromaDB? | Yes | No |
| Use case | "What did Bob say?" | "Summarize the whole meeting" |

### What Each Function Does

| Function | Input | Output | Purpose |
|----------|-------|--------|---------|
| `read_transcript(filepath)` | Path to .txt file | String of text | Same as Task 1, reads the file |
| `extract_insights(text)` | Transcript text | Parsed JSON dict | Sends text to LLM with extraction prompt, parses response |
| `parse_json_response(raw)` | Raw LLM output | Python dict | Handles messy LLM output (code fences, extra text) |
| `print_insights(insights)` | Parsed insights dict | Printed output | Pretty-prints the 4 sections to terminal |
| `extract_from_file(filepath)` | Path to .txt file | Parsed JSON dict | Convenience: reads file then extracts insights |

### The Prompt Engineering

The entire magic is in the prompt. We tell the LLM:

1. **Exactly what format** to use (JSON with specific field names)
2. **A concrete example** so it understands "fill in real data, don't copy the template"
3. **Rules** — only use info from the transcript, don't invent things
4. **Output constraint** — return ONLY JSON, nothing else

Small models like tinyllama couldn't follow this prompt (they copied the template placeholders). phi3 (3.8B parameters) handles it well.

### The JSON Parsing Problem

LLMs don't always return clean JSON. Common issues:
- Adding "Here are the insights:" before the JSON
- Wrapping JSON in \`\`\`json ... \`\`\` code fences
- Trailing text after the JSON closing brace

The `parse_json_response()` function tries 3 approaches:
1. Direct parse — maybe it's already valid JSON
2. Strip code fences — remove \`\`\` markers and try again
3. Find braces — locate the first `{` and last `}`, parse everything between

### Run and Verify

```bash
python3 insights.py
```

Expected output shows 4 sections:
- ACTION ITEMS — who does what, by when
- DECISIONS — what was agreed, who proposed it
- KEY DISCUSSION POINTS — topic summaries
- PARTICIPANT CONTRIBUTIONS — each person's role and input

Also saves the raw JSON to `data/insights_output.json`.

---

## 8. Task 4 — FastAPI Orchestrator

**File:** `server.py`

**Goal:** Create an API server that exposes all functionality as HTTP endpoints. The key endpoint is `/orchestrate`, which combines Task 3 + Task 2 in a single call.

### All Endpoints

| Method | Path | What It Does | Maps To |
|--------|------|-------------|---------|
| POST | `/ingest` | Ingest one transcript | Task 1 |
| POST | `/ingest/all` | Ingest all files in a folder | Task 1 |
| POST | `/query` | Ask a question, get RAG answer | Task 2 |
| POST | `/insights` | Extract structured insights | Task 3 |
| POST | `/orchestrate` | Insights + optional query combined | Task 3 + 2 |
| GET | `/status` | Health check with ChromaDB stats | — |

### How the Orchestrator Works

```
POST /orchestrate
Body: {
  "file_path": "./data/transcripts/sprint_planning.txt",
  "question": "Who is handling notifications?"
}
        |
        v
1. Read the transcript file
        |
        v
2. Call extract_insights() (Task 3)
   → Returns action items, decisions, etc.
        |
        v
3. Check if a question was provided → YES
        |
        v
4. Call query() (Task 2)
   → Search ChromaDB → context → LLM → answer
        |
        v
5. Combine both results:
{
  "insights": { action_items, decisions, ... },
  "query_answer": "Carol will build the notification backend...",
  "query_sources": [...]
}
        |
        v
6. Return combined JSON to client
```

### Pydantic Request Models

FastAPI uses Pydantic models to validate incoming data. When we define:

```python
class QueryRequest(BaseModel):
    question: str
    top_k: Optional[int] = None
```

FastAPI automatically:
- Rejects requests without `question` (it's required)
- Accepts requests without `top_k` (it's optional, defaults to None)
- Returns a helpful error message with the exact validation problem
- Generates API documentation showing what fields are expected

### Run and Test

```bash
# start the server
python3 server.py

# in another terminal, test the status endpoint
curl http://localhost:8000/status

# test querying
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"question": "What was decided about rate limiting?"}'

# test the orchestrator
curl -X POST http://localhost:8000/orchestrate \
  -H "Content-Type: application/json" \
  -d '{"file_path": "./data/transcripts/sprint_planning.txt", "question": "Who has action items?"}'
```

Or just open http://localhost:8000/docs in your browser for the interactive Swagger UI.

---

## 9. Testing the Complete System

### End-to-End Test (all 4 tasks in order)

```bash
# make sure Ollama is running in another terminal
ollama serve

# activate the environment
cd /Users/ritik/Documents/Work/Mine/AI
source venv/bin/activate

# Task 1: ingest transcripts
python3 ingest.py

# Task 2: test queries
python3 query.py

# Task 3: test insight extraction
python3 insights.py

# Task 4: start the API
python3 server.py
```

### Test via API (with server running)

```bash
# check system health
curl http://localhost:8000/status

# ingest a transcript via API
curl -X POST http://localhost:8000/ingest \
  -H "Content-Type: application/json" \
  -d '{"file_path": "./data/transcripts/sprint_planning.txt"}'

# ask a question via API
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"question": "What technology stack was discussed?"}'

# extract insights via API
curl -X POST http://localhost:8000/insights \
  -H "Content-Type: application/json" \
  -d '{"file_path": "./data/transcripts/sprint_planning.txt"}'

# use the orchestrator (both at once)
curl -X POST http://localhost:8000/orchestrate \
  -H "Content-Type: application/json" \
  -d '{"file_path": "./data/transcripts/sprint_planning.txt", "question": "What are the deadlines?"}'
```

---

## 10. Project File Structure

```
AI/
├── .env                              # All configuration values
│     OLLAMA_BASE_URL                   → where Ollama runs
│     OLLAMA_EMBED_MODEL                → nomic-embed-text
│     OLLAMA_LLM_MODEL                  → phi3
│     CHROMA_DB_PATH                    → where vectors are stored
│     CHUNK_SIZE, CHUNK_OVERLAP, TOP_K  → tuning parameters
│
├── requirements.txt                  # Python packages
│
├── ingest.py                         # Task 1: transcript → chunks → embeddings → ChromaDB
├── query.py                          # Task 2: question → search → context → LLM → answer
├── insights.py                       # Task 3: transcript → LLM → structured JSON
├── server.py                         # Task 4: FastAPI server with /orchestrate endpoint
│
├── documents/
│   ├── Task1_Data_Pipeline.md        # Detailed docs for Task 1
│   ├── Task2_Query_System.md         # Detailed docs for Task 2
│   ├── Task3_Insight_Extraction.md   # Detailed docs for Task 3
│   ├── Task4_FastAPI_Orchestrator.md # Detailed docs for Task 4
│   └── Complete_Project_Guide.md     # This file (everything in one place)
│
└── data/
    ├── transcripts/
    │   └── sprint_planning.txt       # Sample meeting transcript
    ├── chroma_db/                    # Vector database (created by Task 1)
    └── insights_output.json          # JSON output (created by Task 3)
```

### How the Files Connect

```
ingest.py ──writes──> data/chroma_db/
                           ^
                           |
query.py ───reads──────────┘
                           
insights.py ──reads──> data/transcripts/*.txt
                           ^
                           |
server.py ─────imports─> ingest.py, query.py, insights.py
              (calls their functions via HTTP endpoints)
```

---

## 11. Troubleshooting

### Setup Issues

| Problem | Cause | Fix |
|---------|-------|-----|
| `python3: command not found` | Python not installed | Download from python.org |
| `pip: command not found` | Not in virtual environment | Run `source venv/bin/activate` |
| `ModuleNotFoundError` | Package not installed or wrong venv | Activate venv, then `pip install -r requirements.txt` |

### Ollama Issues

| Problem | Cause | Fix |
|---------|-------|-----|
| `Connection refused` on port 11434 | Ollama not running | Run `ollama serve` in a separate terminal |
| `address already in use` | Ollama already running | That's fine, ignore it |
| `model not found` | Model not pulled | Run `ollama pull nomic-embed-text` or `ollama pull phi3` |
| Very slow responses | First run loads model into memory | Normal — subsequent runs are faster |

### Code Issues

| Problem | Cause | Fix |
|---------|-------|-----|
| Empty answers from query | ChromaDB has no data | Run `python3 ingest.py` first |
| Bad JSON from insights | LLM produced invalid output | Run again — LLM output varies, or use a bigger model |
| `Port 8000 in use` | Another server running | Use `uvicorn server:app --port 8001` |
| `ImportError` when running server.py | Wrong directory | Make sure you're in the `AI/` folder |

### Model Choice

| Model | Size | Quality | Speed | Best For |
|-------|------|---------|-------|----------|
| tinyllama | 637MB | Low — can't follow complex instructions | Fast | Simple text generation only |
| phi3 | 2.3GB | Good — follows structured prompts well | Medium | This project (best balance) |
| llama3 | 4.7GB | Excellent — very accurate extraction | Slow | If your system can handle it |
| mistral | 4.1GB | Very good — strong at structured output | Medium | Alternative to llama3 |
