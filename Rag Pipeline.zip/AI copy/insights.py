"""
Task 3 - Structured Insight Extraction
Reads a meeting transcript and uses the LLM to pull out
action items, decisions, key discussion points, and who said what.

Instead of free-form answers (like Task 2), this gives back
structured JSON data that a frontend or report tool can use.
"""

import os
import json
from dotenv import load_dotenv
from langchain_ollama import OllamaLLM
from langchain_core.prompts import PromptTemplate

load_dotenv()

# ---- config from .env ----
OLLAMA_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
LLM_MODEL = os.getenv("OLLAMA_LLM_MODEL", "tinyllama")


# ---- The prompt that tells the LLM exactly what to extract ----

EXTRACTION_PROMPT = """You are a meeting note taker. Read the transcript below and extract key information.

Answer in this exact JSON format (replace the example values with real data from the transcript):

Example:
{{
  "action_items": [
    {{"owner": "John", "task": "Write the report", "deadline": "Friday"}}
  ],
  "decisions": [
    {{"decision": "Use Python for the project", "made_by": "John"}}
  ],
  "key_discussion_points": [
    {{"topic": "Project timeline", "summary": "Team agreed on a 2 week timeline"}}
  ],
  "participant_contributions": [
    {{"name": "John", "role": "Manager", "contributions": "Led the discussion and assigned tasks"}}
  ]
}}

Now extract the REAL action items, decisions, discussion points, and contributions from this transcript. Use actual names and details from the text. Return ONLY the JSON.

TRANSCRIPT:
{transcript}

JSON:"""


# ---- Read a transcript file ----

def read_transcript(filepath):
    """Read a .txt file and return its text."""
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


# ---- Send transcript to LLM and get structured output ----

def extract_insights(transcript_text):
    """
    Send the full transcript to the LLM with instructions
    to extract action items, decisions, discussion points,
    and participant contributions as JSON.
    """
    llm = OllamaLLM(
        model=LLM_MODEL,
        base_url=OLLAMA_URL,
        temperature=0.1,
        num_predict=2048  # limit output length so small models don't loop forever
    )

    prompt = PromptTemplate(
        template=EXTRACTION_PROMPT,
        input_variables=["transcript"]
    )

    chain = prompt | llm

    print("Sending transcript to LLM for extraction...")
    raw_response = chain.invoke({"transcript": transcript_text})

    # try to parse the response as JSON
    parsed = parse_json_response(raw_response)
    return parsed


# ---- Parse the LLM's response into clean JSON ----

def parse_json_response(raw_text):
    """
    LLMs don't always return perfect JSON. Sometimes they add
    extra text before/after, or wrap it in ```json``` blocks.
    This function handles those cases.
    """
    cleaned = raw_text.strip()

    # try 1: maybe it's already valid JSON
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # try 2: strip markdown code fences like ```json ... ```
    if cleaned.startswith("```"):
        lines = cleaned.split("\n")
        # remove first line (```json) and last line (```)
        lines = [l for l in lines if not l.strip().startswith("```")]
        cleaned = "\n".join(lines).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            pass

    # try 3: find the JSON object inside the text
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(cleaned[start:end + 1])
        except json.JSONDecodeError:
            pass

    # nothing worked, return error with the raw text
    return {
        "error": "Could not parse LLM response as JSON",
        "raw_response": raw_text
    }


# ---- Pretty print the results ----

def print_insights(insights):
    """Print the extracted insights in a readable format."""

    if "error" in insights:
        print(f"\nError: {insights['error']}")
        print(f"Raw response:\n{insights['raw_response'][:500]}")
        return

    # action items
    print("\n" + "=" * 50)
    print("ACTION ITEMS")
    print("=" * 50)
    for item in insights.get("action_items", []):
        owner = item.get("owner", "?")
        task = item.get("task", "?")
        deadline = item.get("deadline", "Not specified")
        print(f"  [{owner}] {task} (by: {deadline})")

    # decisions
    print("\n" + "=" * 50)
    print("DECISIONS")
    print("=" * 50)
    for item in insights.get("decisions", []):
        decision = item.get("decision", "?")
        made_by = item.get("made_by", "?")
        print(f"  - {decision} (proposed by: {made_by})")

    # key discussion points
    print("\n" + "=" * 50)
    print("KEY DISCUSSION POINTS")
    print("=" * 50)
    for item in insights.get("key_discussion_points", []):
        topic = item.get("topic", "?")
        summary = item.get("summary", "?")
        print(f"  [{topic}]")
        print(f"    {summary}")

    # participant contributions
    print("\n" + "=" * 50)
    print("PARTICIPANT CONTRIBUTIONS")
    print("=" * 50)
    for item in insights.get("participant_contributions", []):
        name = item.get("name", "?")
        role = item.get("role", "?")
        contributions = item.get("contributions", "?")
        print(f"  {name} ({role})")
        print(f"    {contributions}")


# ---- Full pipeline: file -> extract -> print ----

def extract_from_file(filepath):
    """Read a transcript file and extract structured insights."""
    print(f"Reading: {filepath}")
    text = read_transcript(filepath)
    print(f"  Transcript length: {len(text)} characters")

    insights = extract_insights(text)
    print_insights(insights)

    return insights


# ---- Run directly to test ----

if __name__ == "__main__":
    transcript_file = "./data/transcripts/sprint_planning.txt"
    result = extract_from_file(transcript_file)

    # also save the JSON to a file for reference
    output_path = "./data/insights_output.json"
    with open(output_path, "w") as f:
        json.dump(result, f, indent=2)
    print(f"\nJSON saved to {output_path}")
