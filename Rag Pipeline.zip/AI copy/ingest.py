"""
Task 1 - Data Pipeline
Takes meeting transcript text, breaks it into chunks, 
creates embeddings using Ollama, and stores them in ChromaDB.
"""

import os
from dotenv import load_dotenv
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from langchain_ollama import OllamaEmbeddings
from langchain_chroma import Chroma

load_dotenv()

# ---- config from .env ----
OLLAMA_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
EMBED_MODEL = os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text")
CHROMA_PATH = os.getenv("CHROMA_DB_PATH", "./data/chroma_db")
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "500"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "50"))

COLLECTION = "meeting_transcripts"


# ---- Step 1: Read transcript from file ----

def read_transcript(filepath):
    """Read a .txt file and return its text."""
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


# ---- Step 2: Split text into smaller chunks ----

def split_into_chunks(text):
    """
    Break long text into smaller overlapping pieces.
    
    Why overlap? So that if a sentence gets cut at the boundary,
    the next chunk still has some context from the previous one.
    """
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""]
    )
    chunks = splitter.split_text(text)
    return chunks


# ---- Step 3: Create embedding function ----

def get_embedding_fn():
    """
    Returns an Ollama embedding function.
    This converts text into numbers (vectors) that capture meaning.
    Similar sentences will have similar vectors.
    """
    return OllamaEmbeddings(
        model=EMBED_MODEL,
        base_url=OLLAMA_URL
    )


# ---- Step 4: Store chunks in ChromaDB ----

def store_in_chroma(chunks, source_name="unknown"):
    """
    Takes text chunks, embeds them, and saves to ChromaDB.
    Each chunk gets metadata so we know where it came from.
    """
    # wrap each chunk as a LangChain Document with metadata
    documents = []
    for i, chunk in enumerate(chunks):
        doc = Document(
            page_content=chunk,
            metadata={
                "source": source_name,
                "chunk_index": i,
                "total_chunks": len(chunks)
            }
        )
        documents.append(doc)

    # connect to ChromaDB (creates it if it doesn't exist)
    os.makedirs(CHROMA_PATH, exist_ok=True)
    db = Chroma(
        collection_name=COLLECTION,
        embedding_function=get_embedding_fn(),
        persist_directory=CHROMA_PATH
    )

    # add documents - Chroma will call the embedding function internally
    db.add_documents(documents)

    return len(documents)


# ---- Full pipeline: file -> chunks -> embeddings -> ChromaDB ----

def ingest_file(filepath):
    """Run the full ingestion pipeline on one transcript file."""
    print(f"Reading: {filepath}")
    text = read_transcript(filepath)
    print(f"  Text length: {len(text)} characters")

    print("Splitting into chunks...")
    chunks = split_into_chunks(text)
    print(f"  Created {len(chunks)} chunks")

    print("Embedding and storing in ChromaDB...")
    count = store_in_chroma(chunks, source_name=os.path.basename(filepath))
    print(f"  Stored {count} chunks in ChromaDB")

    return count


def ingest_folder(folder_path):
    """Process all .txt files in a folder."""
    files = [f for f in os.listdir(folder_path) if f.endswith(".txt")]
    
    if not files:
        print(f"No .txt files found in {folder_path}")
        return

    total = 0
    for filename in sorted(files):
        full_path = os.path.join(folder_path, filename)
        count = ingest_file(full_path)
        total += count
        print()

    print(f"Done! Total chunks stored: {total}")
    return total


# ---- Run directly to test ----

if __name__ == "__main__":
    transcript_folder = "./data/transcripts"
    ingest_folder(transcript_folder)
